##################################################
### Load libraries
##################################################

library(readr)
library(dplyr)
library(ggplot2)
library(ggtext)
library(glue)
library(patchwork)

# Import function syntax
source("scripts/manuscript-scripts/sti-functions.R")



##################################################
# Import 2019 data
##################################################

sti_2019 = read_csv("data/sti-2019.csv")



###############################################################
# Sample Proportions
###############################################################

sti3 |>
  select(dp_real_data, dp_student_collect, dp_codebook) |>
  gather(
    dp_real_data, dp_student_collect, dp_codebook,
    key = Question, 
    value = Response
  ) |> 
  group_by(Question, Response) |>
  summarize(
    n = n()
  ) |>
  tidyr::drop_na() |>
  mutate(
    p = n / sum(n),
    N = sum(n)
  ) |>
  ungroup()



###############################################################
# Confidence Intervals
###############################################################

# Real data
N = 224
p_hat = (107 + 45) / N
p_hat + c(-1, 1)*qnorm(.975) * sqrt((p_hat*(1 - p_hat)) / N)


# Student collected data
N = 227
p_hat = (140 + 20 + 3) / N
p_hat + c(-1, 1)*qnorm(.975) * sqrt((p_hat*(1 - p_hat)) / N)


# Data codebooks
N = 221
p_hat = (7 + 11) / N
p_hat + c(-1, 1)*qnorm(.975) * sqrt((p_hat*(1 - p_hat)) / N)



