##################################################
### Load libraries
##################################################

library(tidyverse)
library(forcats)



##################################################
### Import STI data
##################################################

sti = read_csv(here::here("data/sti-2021-07-16.csv"))



##################################################
### Prep data
### Note: Need to get information about each of the items and do some wrangling with them

## Variable naming scheme:
## pp_ : pedagogical practices (item 5)
## ce_ : curricular emphasis (items 7 (general), 8 (data viz), 9 (numerical summaries), 10 (study design), 11 (inference), 12 (investigation cycle), 69 (advanced stats), 26 (simulation))
## dp_ : data practices (item 14), codebook (item 15_15)
## t_ : technology (items 17 (primary), 18 (graphing calc reasons), 19 (open-ended), 20 (read output with graphing calc), 21 (software type), 22 (open-ended), 23 (R grammar with data), 24 (open-ended), 68 (R grammar with data viz), 67 (open-ended), 66 (other tools))
## a_ : assessment (item 35)
## cc_ : course and instructor characteristics (items 37 (course format), 38 (n students), 70 (OER), 39 (TA), 40 (TA tasks), 41 (open-ended), 42 (constraints to update), 43 (open-ended), 44 (institution), 45 (open-ended), 46 (department), 47 (open-ended), 48 (position), 49 (open-ended), 50 (years teaching), 51 (open-ended))
##################################################

sti2 = sti %>%
  mutate(

    # Modify pedagogical practices items (i.e., relevel)
    pp_lectures = factor(Q5_1), 
    pp_activities = factor(Q5_2), 
    pp_collab_activity = factor(Q5_3), 
    pp_collab_assess = factor(Q5_4), 
    pp_discovery = factor(Q5_5), 
    pp_technology = factor(Q5_6), 
    
    # Modify general curricular emphasis items (i.e., relevel)
    ce_variability = factor(Q7_6), 
    ce_variability = fct_relevel(ce_variability, 
                              "No Emphasis", 
                              "Minor Emphasis", 
                              "Moderate Emphasis", 
                              "Major Emphasis"), 
    ce_crit_consumer = factor(Q7_7), 
    ce_crit_consumer = fct_relevel(ce_crit_consumer, 
                               "No Emphasis", 
                               "Minor Emphasis", 
                               "Moderate Emphasis", 
                               "Major Emphasis"), 
    ce_ethics = factor(Q7_8), 
    ce_ethics = fct_relevel(ce_ethics, 
                         "No Emphasis", 
                         "Minor Emphasis", 
                         "Moderate Emphasis", 
                         "Major Emphasis"), 
    
    # Modify graphs curricular emphasis items (i.e., relevel)
    ce_viz_1hand = factor(Q8_2), 
    ce_viz_1hand = fct_relevel(ce_viz_1hand, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"), 
    ce_viz_1tech = factor(Q8_7), 
    ce_viz_1tech = fct_relevel(ce_viz_1tech, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"),
    ce_viz_1interp = factor(Q8_3), 
    ce_viz_1interp = fct_relevel(ce_viz_1interp, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"),
    ce_viz_2hand = factor(Q8_8), 
    ce_viz_2hand = fct_relevel(ce_viz_2hand, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"),
    ce_viz_2tech = factor(Q8_9), 
    ce_viz_2tech = fct_relevel(ce_viz_2tech, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"),
    ce_viz_2interp = factor(Q8_10), 
    ce_viz_2interp = fct_relevel(ce_viz_2interp, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"),
    ce_viz_3hand = factor(Q8_11), 
    ce_viz_3hand = fct_relevel(ce_viz_3hand, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"),
    ce_viz_3tech = factor(Q8_12), 
    ce_viz_3tech = fct_relevel(ce_viz_3tech, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"),
    ce_viz_3interp = factor(Q8_13), 
    ce_viz_3interp = fct_relevel(ce_viz_3interp, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"),
    
    # Modify summaries curricular emphasis items (i.e., relevel)
    ce_sum_1hand = factor(Q9_2), 
    ce_sum_1hand = fct_relevel(ce_sum_1hand, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"), 
    ce_sum_1tech = factor(Q9_7), 
    ce_sum_1tech = fct_relevel(ce_sum_1tech, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"),
    ce_sum_1interp = factor(Q9_3), 
    ce_sum_1interp = fct_relevel(ce_sum_1interp, 
                              "No Emphasis", 
                              "Minor Emphasis", 
                              "Moderate Emphasis", 
                              "Major Emphasis"),
    ce_sum_2hand = factor(Q9_8), 
    ce_sum_2hand = fct_relevel(ce_sum_2hand, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"),
    ce_sum_2tech = factor(Q9_9), 
    ce_sum_2tech = fct_relevel(ce_sum_2tech, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"),
    ce_sum_2interp = factor(Q9_10), 
    ce_sum_2interp = fct_relevel(ce_sum_2interp, 
                              "No Emphasis", 
                              "Minor Emphasis", 
                              "Moderate Emphasis", 
                              "Major Emphasis"),
    ce_sum_3hand = factor(Q9_11), 
    ce_sum_3hand = fct_relevel(ce_sum_3hand, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"),
    ce_sum_3tech = factor(Q9_12), 
    ce_sum_3tech = fct_relevel(ce_sum_3tech, 
                            "No Emphasis", 
                            "Minor Emphasis", 
                            "Moderate Emphasis", 
                            "Major Emphasis"),
    ce_sum_3interp = factor(Q9_13), 
    ce_sum_3interp = fct_relevel(ce_sum_3interp, 
                              "No Emphasis", 
                              "Minor Emphasis", 
                              "Moderate Emphasis", 
                              "Major Emphasis"),
    
    # Modify design curricular emphasis items (i.e., relevel)
    ce_random_sample = factor(Q10_1), 
    ce_random_sample = fct_relevel(ce_random_sample, 
                                "No Emphasis", 
                                "Minor Emphasis", 
                                "Moderate Emphasis", 
                                "Major Emphasis"), 
    ce_random_assign = factor(Q10_2), 
    ce_random_assign = fct_relevel(ce_random_assign, 
                                "No Emphasis", 
                                "Minor Emphasis", 
                                "Moderate Emphasis", 
                                "Major Emphasis"),
    ce_results_valid = factor(Q10_3), 
    ce_results_valid = fct_relevel(ce_results_valid, 
                                "No Emphasis", 
                                "Minor Emphasis", 
                                "Moderate Emphasis", 
                                "Major Emphasis"),
    
    # Modify inference curricular emphasis items (i.e., relevel)
    ce_hyp_test = factor(Q11_1), 
    ce_hyp_test = fct_relevel(ce_hyp_test, 
                           "No Emphasis", 
                           "Minor Emphasis", 
                           "Moderate Emphasis", 
                           "Major Emphasis"), 
    ce_CI = factor(Q11_2), 
    ce_CI = fct_relevel(ce_CI, 
                     "No Emphasis", 
                     "Minor Emphasis", 
                     "Moderate Emphasis", 
                     "Major Emphasis"),
    ce_assumptions = factor(Q11_3), 
    ce_assumptions = fct_relevel(ce_assumptions, 
                              "No Emphasis", 
                              "Minor Emphasis", 
                              "Moderate Emphasis", 
                              "Major Emphasis"),
    ce_limitations = factor(Q11_4), 
    ce_limitations = fct_relevel(ce_limitations, 
                              "No Emphasis", 
                              "Minor Emphasis", 
                              "Moderate Emphasis", 
                              "Major Emphasis"),
    ce_communicate_inf = factor(Q11_5), 
    ce_communicate_inf = fct_relevel(ce_communicate_inf, 
                              "No Emphasis", 
                              "Minor Emphasis", 
                              "Moderate Emphasis", 
                              "Major Emphasis"),
    ce_dist_tables = factor(Q11_6), 
    ce_dist_tables = fct_relevel(ce_dist_tables, 
                              "No Emphasis", 
                              "Minor Emphasis", 
                              "Moderate Emphasis", 
                              "Major Emphasis"),
    ce_p_values = factor(Q11_7), 
    ce_p_values = fct_relevel(ce_p_values, 
                           "No Emphasis", 
                           "Minor Emphasis", 
                           "Moderate Emphasis", 
                           "Major Emphasis"),
    ce_supp_pvalue = factor(Q11_8), 
    ce_supp_pvalue = fct_relevel(ce_supp_pvalue, 
                              "No Emphasis", 
                              "Minor Emphasis", 
                              "Moderate Emphasis", 
                              "Major Emphasis"),
    
    # Modify stat investigation curricular emphasis items (i.e., relevel)
    ce_question = factor(Q12_1), 
    ce_question = fct_relevel(ce_question, 
                           "No Emphasis", 
                           "Minor Emphasis", 
                           "Moderate Emphasis", 
                           "Major Emphasis"), 
    ce_design = factor(Q12_2), 
    ce_design = fct_relevel(ce_design, 
                         "No Emphasis", 
                         "Minor Emphasis", 
                         "Moderate Emphasis", 
                         "Major Emphasis"),
    ce_collect = factor(Q12_3), 
    ce_collect = fct_relevel(ce_collect, 
                          "No Emphasis", 
                          "Minor Emphasis", 
                          "Moderate Emphasis", 
                          "Major Emphasis"),
    ce_analyze = factor(Q12_4), 
    ce_analyze = fct_relevel(ce_analyze, 
                          "No Emphasis", 
                          "Minor Emphasis", 
                          "Moderate Emphasis", 
                          "Major Emphasis"),
    ce_draw_conclu = factor(Q12_5), 
    ce_draw_conclu = fct_relevel(ce_draw_conclu, 
                              "No Emphasis", 
                              "Minor Emphasis", 
                              "Moderate Emphasis", 
                              "Major Emphasis"),
    ce_communicate_results = factor(Q12_6), 
    ce_communicate_results = fct_relevel(ce_communicate_results, 
                              "No Emphasis", 
                              "Minor Emphasis", 
                              "Moderate Emphasis", 
                              "Major Emphasis"),
    
    # Modify advanced stat topics curricular emphasis items (i.e., relevel)
    ce_bayesian = factor(Q69_1), 
    ce_bayesian = fct_relevel(ce_bayesian, 
                           "No Emphasis", 
                           "Minor Emphasis", 
                           "Moderate Emphasis", 
                           "Major Emphasis"), 
    ce_causal = factor(Q69_4), 
    ce_causal = fct_relevel(ce_causal, 
                         "No Emphasis", 
                         "Minor Emphasis", 
                         "Moderate Emphasis", 
                         "Major Emphasis"),
    ce_modern_viz = factor(Q69_3), 
    ce_modern_viz = fct_relevel(ce_modern_viz, 
                             "No Emphasis", 
                             "Minor Emphasis", 
                             "Moderate Emphasis", 
                             "Major Emphasis"),
    ce_covariates = factor(Q69_5), 
    ce_covariates = fct_relevel(ce_covariates, 
                             "No Emphasis", 
                             "Minor Emphasis", 
                             "Moderate Emphasis", 
                             "Major Emphasis"),
    ce_unsup_learning = factor(Q69_2), 
    ce_unsup_learning = fct_relevel(ce_unsup_learning, 
                                 "No Emphasis", 
                                 "Minor Emphasis", 
                                 "Moderate Emphasis", 
                                 "Major Emphasis"),
    
    # Modify simulation use item (i.e., rename)
    ce_simulation = factor(Q26), 

    # Modify dataset type items (i.e., relevel)
    dp_real_data = factor(Q14_1), 
    dp_real_data = fct_relevel(dp_real_data, 
                           "None", 
                           "A few", 
                           "About half", 
                           "Most", 
                           "All"), 
    dp_multi_vartypes = factor(Q14_7), 
    dp_multi_vartypes = fct_relevel(dp_multi_vartypes, 
                                 "None", 
                                 "A few", 
                                 "About half", 
                                 "Most", 
                                 "All"),
    dp_student_collect = factor(Q14_2), 
    dp_student_collect = fct_relevel(dp_student_collect, 
                                  "None", 
                                  "A few", 
                                  "About half", 
                                  "Most", 
                                  "All"),
    dp_n_100_to_1000 = factor(Q14_3), 
    dp_n_100_to_1000 = fct_relevel(dp_n_100_to_1000, 
                                "None", 
                                "A few", 
                                "About half", 
                                "Most", 
                                "All"),
    dp_n_gt1000 = factor(Q14_4), 
    dp_n_gt1000 = fct_relevel(dp_n_gt1000, 
                           "None", 
                           "A few", 
                           "About half", 
                           "Most", 
                           "All"),
    dp_col_2 = factor(Q14_5), 
    dp_col_2 = fct_relevel(dp_col_2, 
                        "None", 
                        "A few", 
                        "About half", 
                        "Most", 
                        "All"),
    dp_col_3 = factor(Q14_8), 
    dp_col_3 = fct_relevel(dp_col_3, 
                        "None", 
                        "A few", 
                        "About half", 
                        "Most", 
                        "All"),
    dp_col_gt3 = factor(Q14_9), 
    dp_col_gt3 = fct_relevel(dp_col_gt3, 
                          "None", 
                          "A few", 
                          "About half", 
                          "Most", 
                          "All"),
    
    # Modify codebook item (i.e., relevel)
    dp_codebook = factor(Q15_15), 
    dp_codebook = fct_relevel(dp_codebook, 
                              "No Emphasis", 
                              "Minor Emphasis", 
                              "Moderate Emphasis", 
                              "Major Emphasis"),
    
    # Modify technology items (i.e., rename)
    t_calc_nofxn = factor(Q17_1), 
    t_calc_withfxn = factor(Q17_2), 
    t_software = factor(Q17_3), 
    
    # Modify graphing calculator reason items (i.e., rename)
    t_no_computer = factor(Q18_1), 
    t_course_constraints = factor(Q18_2), 
    t_time_constraints = factor(Q18_3), 
    t_student_constraints = factor(Q18_4), 
    t_instructor_constraints = factor(Q18_5), 
    t_other_constraints = factor(Q18_6), 
    t_see_output_gc = factor(Q20), 
    
    ##Q19 - open-ended item on graphing calculator reasons##
    
    # Modify software type items (i.e., rename)
    t_CODAP = factor(Q21_11), 
    t_Excel = factor(Q21_1), 
    t_Fathom = factor(Q21_2), 
    t_JMP = factor(Q21_3), 
    t_Minitab = factor(Q21_4), 
    t_Python = factor(Q21_21),
    t_R_GUI = factor(Q21_18), 
    t_R_Studio = factor(Q21_19), 
    t_R_Studio_Cloud = factor(Q21_17), 
    t_SAS = factor(Q21_20), 
    t_SAS_U = factor(Q21_13), 
    t_SPSS = factor(Q21_7),
    t_Stata = factor(Q21_8), 
    t_StatCrunch = factor(Q21_14), 
    t_Statkey = factor(Q21_15), 
    t_Tableau = factor(Q21_16), 
    t_TinkerPlots = factor(Q21_9),
    t_Other = factor(Q21_10), 
    
    ##Q22 - open-ended item on other software types##
    
    # Modify R grammar with data items (i.e., rename)
    t_base_R_data = factor(Q23_2), 
    t_mosaic_R_data = factor(Q23_1), 
    t_tidyverse_R_data = factor(Q23_3),
    t_other_R_data = factor(Q23_4),
    
    ##Q24 - open-ended item on other R grammars with data##
    
    # Modify R grammar with data viz items (i.e., rename)
    t_base_R_viz = factor(Q68_2), 
    t_mosaic_R_viz = factor(Q68_1), 
    t_tidyverse_R_viz = factor(Q68_3),
    t_other_R_viz = factor(Q68_4),
    
    ##Q67 - open-ended item on other R grammars with data viz##
    
    # Modify R/Python tool items (i.e., rename)
    t_github = factor(Q66_5), 
    t_jupyter_note = factor(Q66_3), 
    t_learnR_tutorial = factor(Q66_4),
    t_Rmd_doc = factor(Q66_2),
    t_shiny_app = factor(Q66_1),
    
    # Modify assessment items (i.e., relevel)
    a_procedural = factor(Q35_1), 
    a_procedural = fct_relevel(a_procedural, 
                             "Strongly Disagree", 
                             "Disagree", 
                             "Agree", 
                             "Strongly Agree"), 
    a_reasoning = factor(Q35_2), 
    a_reasoning = fct_relevel(a_reasoning, 
                             "Strongly Disagree", 
                             "Disagree", 
                             "Agree", 
                             "Strongly Agree"), 
    a_critical = factor(Q35_4), 
    a_critical = fct_relevel(a_critical, 
                             "Strongly Disagree", 
                             "Disagree", 
                             "Agree", 
                             "Strongly Agree"), 
    a_formative = factor(Q35_3), 
    a_formative = fct_relevel(a_formative, 
                             "Strongly Disagree", 
                             "Disagree", 
                             "Agree", 
                             "Strongly Agree"), 
    
    # Modify course characteristics items (i.e., rename)
    cc_course_type = factor(Q37), 
    cc_n_students = Q38, 
    cc_OER = factor(Q70), 
    
    # Modify course TA items (i.e., rename)
    cc_TA = factor(Q39), 
    cc_TA_facilitate = factor(Q40_1), 
    cc_TA_grade = factor(Q40_2),
    cc_TA_OH = factor(Q40_3),
    cc_TA_lab = factor(Q40_4),
    cc_TA_lecture = factor(Q40_5),
    cc_TA_student_q = factor(Q40_7),
    cc_TA_other = factor(Q40_6),
    
    ##Q41 - open-ended item on other TA tasks##
    
    # Modify course/instructor constraint items (i.e., rename)
    cc_constraints_time = factor(Q42_1), 
    cc_constraints_dept = factor(Q42_2),
    cc_constraints_external = factor(Q42_3),
    cc_constraints_student = factor(Q42_5),
    cc_constraints_tech = factor(Q42_4),
    cc_constraints_textbook = factor(Q42_7),
    cc_constraints_other = factor(Q42_6),
    
    ##Q43 - open-ended item on other constraints##
    
    # Modify institution labels/levels (i.e., shorten name, relevel, assign NA to Other)
    cc_institution = factor(Q44),
    cc_institution = fct_recode(cc_institution, 
                             "University" = "University (grant advanced degrees)"), 
    cc_institution = fct_relevel(cc_institution, 
                              "Two-year college", 
                              "Four-year college", 
                              "University", 
                              "Other"), 
    cc_institution = fct_explicit_na(cc_institution, na_level = "Other"), 
    
    # Modify course department items (i.e., rename)
    cc_dept = factor(Q46), 
    
    ##Q47 - open-ended item on other department##
    
    # Modify instructor characteristic items (i.e., rename)
    cc_position = factor(Q48), 
    
    ##Q49 - open-ended item on other position##
    
    cc_years = factor(Q50), 
    cc_years = fct_relevel(cc_years, 
                           "0–5", 
                           "6–10")
    
    ##Q51 - open-ended item on other position##
    
  ) %>%
  select(starts_with("pp_"), starts_with("ce_"), starts_with("dp_"), starts_with("t_"), starts_with("a_"), starts_with("cc_"))

# Count NAs for each row (91 items in the 5 sections)
sti2$na_count = apply(sti2, 1, function(x) sum(is.na(x)))



# Omit data with more than 77 missing items (more than 85% of items missing)
# Remove identifying attributes and unused attributes
# Remove non-tertiary-level instructors
sti3 = sti2 %>%
  filter(na_count < 77) |>
  filter(cc_institution != "Other") |>
  select(!c(ce_analyze, ce_draw_conclu, ce_communicate_results, ce_bayesian:ce_unsup_learning, dp_multi_vartypes, dp_n_100_to_1000:dp_col_gt3,
            t_base_R_data:t_shiny_app, cc_course_type:cc_constraints_other, cc_dept:cc_years))


names(sti3)

nrow(sti3)
# 228



##################################################
### Export STI computing data
##################################################

write.csv(sti3, file = here::here("data/sti-2019.csv"), row.names = FALSE)


