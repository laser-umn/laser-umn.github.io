##################################################
### Load libraries
##################################################

library(tidyverse)
library(ggtext)
library(glue)
library(patchwork)
library(scales)

# Import function syntax
source("scripts/manuscript-scripts/sti-functions.R")



##################################################
# Import 2019 data
##################################################

sti_2019 = read_csv("data/sti-2019.csv")




###############################################################
# Sample Proportions
###############################################################

use_tech                     = prop_emphasis(pp_technology)
encounter_simulation         = prop_emphasis(ce_simulation)
critical_values              = prop_emphasis(ce_dist_tables)
produce_univariate_viz       = prop_emphasis(ce_viz_1tech)  
produce_bivariate_viz        = prop_emphasis(ce_viz_2tech)
produce_multivariate_viz     = prop_emphasis(ce_viz_3tech)
produce_univariate_summary   = prop_emphasis(ce_sum_1tech)
produce_bivariate_summary    = prop_emphasis(ce_sum_2tech)
produce_multivariate_summary = prop_emphasis(ce_sum_3tech)
excel                        = prop_emphasis(t_Excel)
python                       = prop_emphasis(t_Python)
r_gui                        = prop_emphasis(t_R_GUI)
r_studio                     = prop_emphasis(t_R_Studio)
r_studio_cloud               = prop_emphasis(t_R_Studio_Cloud)
sas                          = prop_emphasis(t_SAS)
sas_studio                   = prop_emphasis(t_SAS_U)
codap                        = prop_emphasis(t_CODAP)
fathom                       = prop_emphasis(t_Fathom)
tinkerplots                  = prop_emphasis(t_TinkerPlots)
statkey                      = prop_emphasis(t_Statkey)
jmp                          = prop_emphasis(t_JMP)
minitab                      = prop_emphasis(t_Minitab)
spss                         = prop_emphasis(t_SPSS)
stata                        = prop_emphasis(t_Stata)
statcrunch                   = prop_emphasis(t_StatCrunch)
tableau                      = prop_emphasis(t_Tableau)
other                        = prop_emphasis(t_Other)



###############################################################
# Confidence Intervals
###############################################################

# Tech to explore concepts (use_tech)
N = 227
p_hat = (62 + 151) / N
p_hat + c(-1, 1)*qnorm(.975) * sqrt((p_hat*(1 - p_hat)) / N)


# Simulation (encounter_simulation)
N = 227
p_hat = (116) / N
p_hat + c(-1, 1)*qnorm(.975) * sqrt((p_hat*(1 - p_hat)) / N)


# Critical values
N = 228
p_hat = (30 + 54 + 26) / N
p_hat + c(-1, 1)*qnorm(.975) * sqrt((p_hat*(1 - p_hat)) / N)


# Critical values
N = 228
p_hat = (30 + 54 + 26) / N
p_hat + c(-1, 1)*qnorm(.975) * sqrt((p_hat*(1 - p_hat)) / N)



# Desktop/Web-based software as primary tech tool
techp_data = sti_2019 |>
  select(t_calc_nofxn, t_calc_withfxn, t_software) |>
  tibble::rowid_to_column("uniq_id") %>%
  pivot_longer(cols = starts_with("t_"), names_to="tech", values_to = "use") %>%
  mutate(
    tech = factor(tech), 
    use = factor(use), 
    use = forcats::fct_relevel(use, "No", "Yes")) |>
  group_by(tech, use) |>
  summarize(
    n = n()
  ) |>
  tidyr::drop_na() |>
  mutate(
    p = n / sum(n),
    N = sum(n)
  ) |>
  ungroup() |>
  filter(use == "Yes") |>
  select(version = tech, n, p, N) |>
  mutate(year = 2019, question = "Technology")


# CI
N = 228
p_hat = 204 / N
p_hat + c(-1, 1)*qnorm(.975) * sqrt((p_hat*(1 - p_hat)) / N)



###############################################################
# Figure 5
###############################################################

# Prepare data
prod_tech_viz1_2019 = figure_prop_emphasis(ce_viz_1tech, question_text = "Produce Univariate Viz")  
prod_tech_viz2_2019 = figure_prop_emphasis(ce_viz_2tech, question_text = "Produce Bivariate Viz")
prod_tech_viz3_2019 = figure_prop_emphasis(ce_viz_3tech, question_text = "Produce Multivariate Viz")
prod_tech_num1_2019 = figure_prop_emphasis(ce_sum_1tech, question_text = "Produce Univariate Summaries")  
prod_tech_num2_2019 = figure_prop_emphasis(ce_sum_2tech, question_text = "Produce Bivariate Summaries")
prod_tech_num3_2019 = figure_prop_emphasis(ce_sum_3tech, question_text = "Produce Multivariate Summaries")


d2 = rbind(prod_tech_viz1_2019, prod_tech_viz2_2019, prod_tech_viz3_2019, 
           prod_tech_num1_2019, prod_tech_num2_2019, prod_tech_num3_2019) |>
  mutate(
    question = factor(question, 
                      levels = c("Produce Multivariate Summaries", "Produce Multivariate Viz", 
                                 "Produce Bivariate Viz", "Produce Bivariate Summaries", 
                                 "Produce Univariate Summaries", "Produce Univariate Viz"),
                      labels = c("Multivariate Summaries", "Multivariate Viz", 
                                 "Bivariate Viz", "Bivariate Summaries", 
                                 "Univariate Summaries", "Univariate Viz")
    ),
    color = c("#DDAA33",  "#004488", "#BB5566", "#DDAA33", "#004488", "#BB5566"),
    name = glue("<b style='color:{color}'>{question}</b>"),
    se = sqrt(p*(1 - p) / N),
    ll = p - qnorm(.975)*se,
    ul = p + qnorm(.975)*se,
  ) |>
  arrange(question)


# Create figure
fig_05 = ggplot(data = d2, aes(x = p, y = question)) +
  geom_linerange(aes(xmin = ll, xmax = ul, color = color), size = 1.3) +
  geom_point(aes(color = color), size = 3) +
  guides(color = "none") +
  scale_x_continuous(
    name = "Percentage",
    breaks = seq(from = 0, to = 1, by = 0.2),
    minor_breaks = seq(from = 0.1, to = 0.9, by = 0.2),
    labels = scales::percent
  ) +
  scale_y_discrete(
    name = "",
    labels = d2$name
  ) +
  scale_color_identity() +
  coord_cartesian(xlim = c(0, 1)) +
  theme_bw() +
  theme_bw() +
  theme(
    axis.text = element_text(size = rel(1.1)),
    axis.title = element_text(size = rel(1.1), face = "bold"),
    axis.text.y = element_markdown()
  )

fig_05




###############################################################
# Figure 6
###############################################################

# Get proportions and compute CIs
software_yes_tbl = sti_2019 |>
  select(t_CODAP,t_Excel, t_Fathom, t_JMP, t_Minitab, t_Python,
         t_R_GUI, t_R_Studio, t_R_Studio_Cloud, t_SAS, t_SAS_U,t_SPSS, t_Stata,
         t_StatCrunch, t_Statkey, t_Tableau, t_TinkerPlots, t_Other) |>
  mutate(
    pedagogical = if_else(t_CODAP == "Yes" | t_Fathom == "Yes"| t_TinkerPlots == "Yes" | t_Statkey == "Yes", 1, 0),
    gui = if_else(t_JMP  == "Yes" | t_Minitab  == "Yes", t_SPSS  == "Yes" | t_Stata  == "Yes" | t_StatCrunch == "Yes", 1, 0),
    syntax = if_else(t_Python == "Yes" | t_R_GUI == "Yes" | t_R_Studio  == "Yes" | t_R_Studio_Cloud  == "Yes" | t_SAS  == "Yes" | t_SAS_U  == "Yes", 1, 0),
    excel = if_else(t_Excel == "Yes", 1, 0),
    other = if_else(t_Other == "Yes", 1, 0)
  ) |>
  select(excel, other, pedagogical, gui, syntax) |>
  summarize_all(
    sum, na.rm = TRUE
  ) |>
  gather() |>
  rename(
    Type = key,
    Response = value 
  ) |>
  mutate(
    Type =  c("Excel", "Other", "Pedagogical", "GUI-Based", "Syntax-Driven"),
    version = factor(Type, levels = c("Other", "Excel", "Syntax-Driven", "GUI-Based", "Pedagogical")),
    p = Response / 228,
    se = sqrt(p*(1 - p) / 228),
    ll = p - qnorm(.975)*se,
    ul = p + qnorm(.975)*se,
  )



# Create figure
fig_06 = software_yes_tbl |>
  ggplot(aes(x = p, y = version)) +
  geom_linerange(aes(xmin = ll, xmax = ul), color = "#004488", size = 1.3) +
  geom_point(color = "#004488", size = 3) +
  #facet_wrap(~ version, ncol = 1) +
  guides(color = "none") +
  scale_x_continuous(
    name = "Percentage",
    limits = c(0, 1),
    breaks = seq(from = 0, to = 1, by = 0.2),
    minor_breaks = seq(from = 0.1, to = 0.9, by = 0.2),
    labels = scales::percent
  ) + 
  scale_y_discrete(name = "Software Type") +
  theme_bw() +
  theme(
    axis.text = element_text(size = rel(1.1)),
    axis.title = element_text(size = rel(1.1), face = "bold"),
    plot.title = element_textbox_simple(
      size = 14,
      lineheight = 1,
      padding = margin(5.5, 5.5, 5.5, 5.5),
      margin = margin(0, 0, 5.5, 0)
    )
  )

fig_06  

ggsave(filename = "~/Desktop/fig_06.png", fig_06, width = 8, height = 5)










