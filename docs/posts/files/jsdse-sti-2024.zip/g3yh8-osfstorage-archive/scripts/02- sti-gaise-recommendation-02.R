##################################################
### Load libraries
##################################################

library(tidyverse)
library(ggtext)
library(glue)
library(patchwork)
library(scales)


# Import function syntax
source("scripts/manuscript-scripts/sti-functions.R")



##################################################
# Import 2019 data
##################################################

sti_2019 = read_csv("data/sti-2019.csv")




###############################################################
# Sample Proportions
###############################################################

assess_reasoning  = prop_emphasis(a_reasoning)
assess_reasoning

assess_procedural = prop_emphasis(a_procedural)
assess_procedural


###############################################################
# Confidence Intervals
###############################################################

# Procedural
N = 227
p_hat = (49 + 101) / N
p_hat + c(-1, 1)*qnorm(.975) * sqrt((p_hat*(1 - p_hat)) / N)


# Reasoning
N = 226
p_hat = (129 + 89) / N
p_hat + c(-1, 1)*qnorm(.975) * sqrt((p_hat*(1 - p_hat)) / N)


