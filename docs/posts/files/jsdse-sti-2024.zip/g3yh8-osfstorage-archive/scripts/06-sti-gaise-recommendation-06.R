##################################################
### Load libraries
##################################################

library(tidyverse)
library(ggtext)
library(glue)
library(patchwork)
library(scales)

# Import function syntax
source("scripts/manuscript-scripts/sti-functions.R")


##################################################
### Import 2019 data
##################################################

sti_2019 = read_csv("data/sti-2019.csv")




###############################################################
# Sample proportions
###############################################################

reasoning       = prop_emphasis(a_reasoning)
procedural      = prop_emphasis(a_procedural)
critically_eval = prop_emphasis(a_critical)
formative.      = prop_emphasis(a_formative)
collab_assess   = prop_emphasis(pp_collab_assess)
  



###############################################################
# Figure 7
###############################################################

# Prepare data
proc          = figure_prop_agreement(a_procedural, question_text = "Procedural")
reas          = figure_prop_agreement(a_reasoning, question_text = "Reasoning")
crit          = figure_prop_agreement(a_critical, question_text = "Critical")
form          = figure_prop_agreement(a_formative, question_text = "Formative")
collab_assess = figure_prop_agreement(pp_collab_assess, question_text = "Collab")


d1 = rbind(reas, proc, crit, form, collab_assess) |>
  mutate(
    question = factor(question, 
                      levels = c("Collab", "Formative", "Critical", "Procedural", "Reasoning"),
                      labels = c("Collaborative<br />Assessment", "Formative<br />Assessment", "Critical<br />Evaluation", "Procedural<br />Skills", "Statistical<br />Reasoning")
    ),
    color = c("#004488", "#004488", "#004488", "#DDAA33", "#DDAA33"),
    name = glue("<b style='color:{color}'>{question}</b>"),
    se = sqrt(p*(1 - p) / N),
    ll = p - qnorm(.975)*se,
    ul = p + qnorm(.975)*se,
  ) |>
  arrange(question)


# Create figure
fig_07 =  ggplot(data = d1, aes(x = p, y = question)) +
  geom_linerange(aes(xmin = ll, xmax = ul, color = color), size = 1.3) +
  geom_point(aes(color = color), size = 3) +
  guides(color = "none") +
  scale_x_continuous(
    name = "Percentage",
    limits = c(0, 1),
    breaks = seq(from = 0, to = 1, by = 0.2),
    minor_breaks = seq(from = 0.1, to = 0.9, by = 0.2),
    labels = scales::percent
  ) +
  scale_y_discrete(
    name = "",
    labels = d1$name
  ) +
  scale_color_identity() +
  theme_bw() +
  theme(
    #axis.text = element_text(size = rel(1.1)),
    axis.title = element_text(
      #size = rel(1.1), 
      face = "bold"),
    axis.text.y = element_markdown()
  ) 


fig_07





