###############################################################
# Function to get proportion of agreement and sample size for each 
# assessment item and structure in a data frame
###############################################################

prop_emphasis = function(x){
  
  sti_2019 |>
    select({{x}}) |>
    tidyr::drop_na() |>
    group_by({{x}}) |>
    summarize(
      n = n()
    ) |>
    mutate(
      p = n / sum(n),
      N = sum(n)
    ) |>
    ungroup()
}



###############################################################
# Function to compute proportions across the by-hand and using
# tech viz production/nummerical summary production
###############################################################

prop_emphasis2 = function(x, y, question_text){
  
  sti_2019 |>
    select({{x}}, {{y}}) |>
    tidyr::drop_na() |>
    mutate(
      #both = paste({{x}}, {{y}}),
      vr2 = case_when(
        {{x}} == "Major Emphasis" | {{y}} == "Major Emphasis" ~ "Major Emphasis",
        {{x}} == "Moderate Emphasis" | {{y}} == "Moderate Emphasis" ~ "Moderate Emphasis",
        {{x}} == "Minor Emphasis" | {{y}} == "Minor Emphasis" ~ "Minor Emphasis",
        {{x}} == "No Emphasis" & {{y}} == "No Emphasis" ~ "No Emphasis"
      )
    ) |>
    group_by(vr2) |> 
    summarize(
      n = n()
    ) |>
    mutate(
      p = n / sum(n),
      N = sum(n)
    ) |>
    ungroup()
}






###############################################################
# Function to get proportion of emphasis/no emphasis and sample size for each 
# assessment item and structure in a data frame for figures
###############################################################

figure_prop_emphasis = function(x, question_text){
  
  sti_2019 |>
    mutate(vr2 = if_else({{x}} == "No Emphasis" | {{x}} == "Minor Emphasis", "Minor", "Major")) |>
    select(vr2) |>
    tidyr::drop_na() |>
    group_by(vr2) |>
    summarize(
      n = n()
    ) |>
    mutate(
      p = n / sum(n),
      N = sum(n)
    ) |>
    ungroup() |>
    filter(vr2 == "Major") |>
    select(n, p, N) |>
    mutate(year = 2019, question = question_text)
}


###############################################################
# Function to compute proportions across the by-hand and 
# using tech viz production/nummerical summary production for figures
###############################################################

figure_prop_emphasis2 = function(x, y, question_text){
  
  sti_2019 |>
    select({{x}}, {{y}}) |>
    tidyr::drop_na() |>
    mutate(
      both = paste({{x}}, {{y}}),
      vr2 = if_else(both %in% c("Minor Emphasis Minor Emphasis", "Minor Emphasis No Emphasis", 
                                "No Emphasis Minor Emphasis", "No Emphasis No Emphasis"), "Minor", "Major")
    ) |>
    group_by(vr2) |> 
    summarize(
      n = n()
    ) |>
    mutate(
      p = n / sum(n),
      N = sum(n)
    ) |>
    ungroup() |>
    filter(vr2 == "Major") |>
    select(n, p, N) |>
    mutate(year = 2019, question = question_text)
}


figure_prop_agreement = function(x, question_text){
  
  sti_2019 |>
    mutate(vr2 = if_else({{x}} == "Strongly Disagree" | {{x}} == "Disagree", "Disagree", "Agree")) |>
    select(vr2) |>
    tidyr::drop_na() |>
    group_by(vr2) |>
    summarize(
      n = n()
    ) |>
    mutate(
      p = n / sum(n),
      N = sum(n)
    ) |>
    ungroup() |>
    filter(vr2 == "Agree") |>
    select(n, p, N) |>
    mutate(year = 2019, question = question_text)
}
