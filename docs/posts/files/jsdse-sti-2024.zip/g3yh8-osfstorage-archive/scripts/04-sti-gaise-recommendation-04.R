##################################################
### Load libraries
##################################################

library(tidyverse)
library(ggtext)
library(glue)
library(patchwork)
library(scales)
library(tidyr)

# Import function syntax
source("scripts/manuscript-scripts/sti-functions.R")



##################################################
# Import 2019 data
##################################################

sti_2019 = read_csv("data/sti-2019.csv")




###############################################################
# Sample Proportions
###############################################################

lectures    = prop_emphasis(pp_lectures)
activities  = prop_emphasis(pp_activities)
discovery   = prop_emphasis(pp_discovery)  
cooperation = prop_emphasis(pp_collab_activity)  




###############################################################
# Figure 4
###############################################################

# Prepare data
lectures    = figure_prop_agreement(pp_lectures, question_text = "Lecture")
activities  = figure_prop_agreement(pp_activities, question_text = "Activities")
discovery   = figure_prop_agreement(pp_discovery, question_text = "Discovery")  
cooperation = figure_prop_agreement(pp_collab_activity, question_text = "Cooperation") 


# Create Figure 4
fig_04 = rbind(lectures, activities, cooperation, discovery) |>
  mutate(
    question = factor(question, levels = c("Lecture", "Activities", "Discovery", "Cooperation", "Technology")),
    se = sqrt(p*(1 - p) / N),
    ll = p - qnorm(.975)*se,
    ul = p + qnorm(.975)*se,
  ) |>
  arrange(question, year) |>
  ggplot(aes(x = p, y = question)) +
  geom_linerange(aes(xmin = ll, xmax = ul), linewidth = 1.3, color = "#004488") +
  geom_point(size = 3, color = "#004488") +
  guides(color = "none") +
  scale_x_continuous(
    name = "Percentage",
    limits = c(0, 1),
    breaks = seq(from = 0, to = 1, by = 0.2),
    minor_breaks = seq(from = 0.1, to = 0.9, by = 0.2),
    labels = scales::percent
  ) +
  scale_y_discrete(
    name = ""
  ) +
  theme_bw() +
  theme(
    axis.text = element_text(size = rel(1.1)),
    axis.text.y = element_markdown(),
    axis.title = element_text(size = rel(1.1), face = "bold"),
    plot.title = element_textbox_simple(
      size = 14,
      lineheight = 1,
      padding = margin(5.5, 5.5, 5.5, 5.5),
      margin = margin(0, 0, 5.5, 0)
    )
  ) 


fig_04
