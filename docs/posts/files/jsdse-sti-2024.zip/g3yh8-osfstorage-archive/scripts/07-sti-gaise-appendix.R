##################################################
### Load libraries
##################################################

library(tidyverse)
library(scales)

# Import function syntax
source("scripts/manuscript-scripts/sti-functions.R")


##################################################
### Import 2019 data
##################################################

sti_2019 = read_csv("data/sti-2019.csv")



###############################################################
# Recommendation 1
###############################################################

prop_emphasis(ce_results_valid)
prop_emphasis(ce_crit_consumer)
prop_emphasis(ce_ethics)
prop_emphasis(ce_question)
prop_emphasis(ce_design)
prop_emphasis(ce_collect)
prop_emphasis(ce_random_sample)  
prop_emphasis(ce_random_assign)
prop_emphasis2(ce_viz_1tech, ce_viz_1hand)  
prop_emphasis2(ce_viz_2tech, ce_viz_2hand)
prop_emphasis2(ce_viz_3tech, ce_viz_3hand)
prop_emphasis2(ce_sum_1tech, ce_sum_1hand)
prop_emphasis2(ce_sum_2tech, ce_sum_2hand)
prop_emphasis2(ce_sum_3tech, ce_sum_3hand)
prop_emphasis(ce_hyp_test)  
prop_emphasis(ce_CI)
prop_emphasis(ce_viz_1interp)  
prop_emphasis(ce_viz_2interp)
prop_emphasis(ce_viz_3interp)
prop_emphasis(ce_sum_1interp)  
prop_emphasis(ce_sum_2interp)
prop_emphasis(ce_sum_3interp)
prop_emphasis(ce_communicate_inf)
prop_emphasis(ce_p_values)
prop_emphasis(ce_supp_pvalue)
prop_emphasis(ce_results_valid)
prop_emphasis(ce_assumptions)
prop_emphasis(ce_limitations)



###############################################################
# Recommendation 2
###############################################################

prop_emphasis(a_reasoning)
prop_emphasis(a_procedural)



###############################################################
# Recommendation 3
###############################################################

prop_emphasis(dp_real_data)
prop_emphasis(dp_student_collect)
prop_emphasis(dp_codebook)



###############################################################
# Recommendation 4
###############################################################

prop_emphasis(pp_lectures)
prop_emphasis(pp_activities)
prop_emphasis(pp_discovery)  
prop_emphasis(pp_collab_activity)  



###############################################################
# Recommendation 5
###############################################################

prop_emphasis(pp_technology)
prop_emphasis(ce_simulation)
prop_emphasis(ce_dist_tables)
prop_emphasis(ce_viz_1tech)
prop_emphasis(ce_viz_2tech)
prop_emphasis(ce_viz_3tech)
prop_emphasis(ce_sum_1tech)
prop_emphasis(ce_sum_2tech)
prop_emphasis(ce_sum_3tech)
prop_emphasis(t_calc_nofxn)
prop_emphasis(t_calc_withfxn)
prop_emphasis(t_software)
prop_emphasis(t_no_computer)
prop_emphasis(t_course_constraints)
prop_emphasis(t_time_constraints)
prop_emphasis(t_student_constraints)
prop_emphasis(t_instructor_constraints)
prop_emphasis(t_other_constraints)
prop_emphasis(t_see_output_gc)
prop_emphasis(t_Python)
prop_emphasis(t_R_GUI)
prop_emphasis(t_R_Studio)
prop_emphasis(t_R_Studio_Cloud)
prop_emphasis(t_SAS)
prop_emphasis(t_SAS_U)
prop_emphasis(t_CODAP)
prop_emphasis(t_Fathom)
prop_emphasis(t_Tableau)
prop_emphasis(t_TinkerPlots)
prop_emphasis(t_Statkey)
prop_emphasis(t_JMP)
prop_emphasis(t_Minitab)
prop_emphasis(t_SPSS)
prop_emphasis(t_Stata)
prop_emphasis(t_StatCrunch)
prop_emphasis(t_Excel)
prop_emphasis(t_Other)



###############################################################
# Recommendation 6
###############################################################

prop_emphasis(a_reasoning)
prop_emphasis(a_procedural)
prop_emphasis(a_critical)
prop_emphasis(a_formative)
prop_emphasis(pp_collab_assess)

