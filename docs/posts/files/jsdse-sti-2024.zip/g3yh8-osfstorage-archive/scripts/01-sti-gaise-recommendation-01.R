##################################################
### Load libraries
##################################################

library(tidyverse)
library(ggtext)
library(glue)
library(patchwork)
library(scales)

# Import function syntax
source("scripts/manuscript-scripts/sti-functions.R")



##################################################
### Import 2019 data
### Remove non-tertiary-level instructors
##################################################

sti_2019 = read_csv("data/sti-2019.csv")




###############################################################
# Sample Proportions
###############################################################

understand_variability       = prop_emphasis(ce_results_valid)
critically_consume           = prop_emphasis(ce_crit_consumer)
ethical_issues               = prop_emphasis(ce_ethics)  
pose_question                = prop_emphasis(ce_question)
design_study                 = prop_emphasis(ce_design)
collect_data                 = prop_emphasis(ce_collect)
rand_samp                    = prop_emphasis(ce_random_sample)  
rand_assign                  = prop_emphasis(ce_random_assign)
produce_univariate_viz       = prop_emphasis2(ce_viz_1tech, ce_viz_1hand)  
produce_bivariate_viz        = prop_emphasis2(ce_viz_2tech, ce_viz_2hand)
produce_multivariate_viz     = prop_emphasis2(ce_viz_3tech, ce_viz_3hand)
produce_univariate_summary   = prop_emphasis2(ce_sum_1tech, ce_sum_1hand)
produce_bivariate_summary    = prop_emphasis2(ce_sum_2tech, ce_sum_2hand)
produce_multivariate_summary = prop_emphasis2(ce_sum_3tech, ce_sum_3hand)
hyp_test                     = prop_emphasis(ce_hyp_test)  
ci                           = prop_emphasis(ce_CI)
int_univariate_viz           = prop_emphasis(ce_viz_1interp)  
int_bivariate_viz            = prop_emphasis(ce_viz_2interp)
int_multivariate_viz         = prop_emphasis(ce_viz_3interp)
int_univariate_summary       = prop_emphasis(ce_sum_1interp)  
int_bivariate_summary        = prop_emphasis(ce_sum_2interp)
int_multivariate_summary     = prop_emphasis(ce_sum_3interp)
comm_results                 = prop_emphasis(ce_communicate_inf)
p_value_decisions            = prop_emphasis(ce_p_values)
supplement_p_values          = prop_emphasis(ce_supp_pvalue)
validity_of_results          = prop_emphasis(ce_results_valid)
role_of_model                = prop_emphasis(ce_assumptions)
limits_inf                   = prop_emphasis(ce_limitations) 



###############################################################
# Figure 1
###############################################################

# Get data ready for figures
understand_variability = figure_prop_emphasis(ce_results_valid, question_text = "Variability")
critically_consume     = figure_prop_emphasis(ce_crit_consumer, question_text = "Critical Consumers")
ethical_issues         = figure_prop_emphasis(ce_ethics, question_text = "Ethics")  



# Create Figure 1
fig_01 = rbind(understand_variability, critically_consume, ethical_issues) |>
  mutate(
    question = factor(question, levels = c("Ethics", "Critical Consumers",
                                           "Variability")),
    se = sqrt(p*(1 - p) / N),
    ll = p - qnorm(.975)*se,
    ul = p + qnorm(.975)*se,
  ) |>
  arrange(question) |>
  ggplot(aes(x = p, y = question)) +
  geom_linerange(aes(xmin = ll, xmax = ul), color = "#004488", linewidth = 1.3) +
  geom_point(color = "#004488", size = 3) +
  guides(color = "none") +
  scale_x_continuous(
    name = "Percentage",
    breaks = seq(from = 0, to = 1, by = 0.2),
    minor_breaks = seq(from = 0.1, to = 0.9, by = 0.2),
    labels = scales::percent
  ) +
  coord_cartesian(xlim = c(0, 1)) +
  scale_y_discrete(
    name = "",
    labels = c("Ethics", "Critical \n Consumers", "Variability")
  ) +
  theme_bw() +
  theme(
    axis.text = element_text(size = rel(1.1)),
    axis.title = element_text(size = rel(1.1), face = "bold")
  ) 



fig_01



###############################################################
# Figure 2
###############################################################

# Prepare data for figure
pose_question = figure_prop_emphasis(ce_question, question_text = "Pose Question")
design_study  = figure_prop_emphasis(ce_design, question_text = "Design Study")
collect_data  = figure_prop_emphasis(ce_collect, question_text = "Collect Data")
rand_samp     = figure_prop_emphasis(ce_random_sample, question_text = "Random Sample")  
rand_assign   = figure_prop_emphasis(ce_random_assign, question_text = "Random Assignment")


d1 = rbind(pose_question, design_study, collect_data, rand_assign, rand_samp) |>
  mutate(
    question = factor(question, levels = c("Collect Data", "Design Study", "Random Assignment",
                                           "Random Sample", "Pose Question")),
    color = c("#DDAA33", "#004488", "#004488", "#004488", "#BB5566"),
    name = glue("<b style='color:{color}'>{question}</b>"),
    se = sqrt(p*(1 - p) / N),
    ll = p - qnorm(.975)*se,
    ul = p + qnorm(.975)*se,
  ) |>
  arrange(question)


# Create figure
fig_02 = ggplot(data = d1, aes(x = p, y = question)) +
  geom_linerange(aes(xmin = ll, xmax = ul, color = color), linewidth = 1.3) +
  geom_point(aes(color = color), size = 3) +
  guides(color = "none") +
  scale_x_continuous(
    name = "Percentage",
    breaks = seq(from = 0, to = 1, by = 0.2),
    minor_breaks = seq(from = 0.1, to = 0.9, by = 0.2),
    labels = scales::percent
  ) +
  coord_cartesian(xlim = c(0, 1)) +
  scale_y_discrete(
    name = "",
    labels = d1$name
  ) +
  scale_color_identity() +
  theme_bw() +
  theme(
    axis.text = element_text(size = rel(1.1)),
    axis.title = element_text(size = rel(1.1), face = "bold"),
    axis.text.y = element_markdown()
  ) 


fig_02



###############################################################
# Figure 3
###############################################################

# Prepare data
produce_univariate_viz       = figure_prop_emphasis2(ce_viz_1tech, ce_viz_1hand, question_text = "Produce Univariate Viz")  
produce_bivariate_viz        = figure_prop_emphasis2(ce_viz_2tech, ce_viz_2hand, question_text = "Produce Bivariate Viz")
produce_multivariate_viz     = figure_prop_emphasis2(ce_viz_3tech, ce_viz_3hand, question_text = "Produce Multivariate Viz")
produce_univariate_summary   = figure_prop_emphasis2(ce_sum_1tech, ce_sum_1hand, question_text = "Produce Univariate Summaries")
produce_bivariate_summary    = figure_prop_emphasis2(ce_sum_2tech, ce_sum_2hand, question_text = "Produce Bivariate Summaries")
produce_multivariate_summary = figure_prop_emphasis2(ce_sum_3tech, ce_sum_3hand, question_text = "Produce Multivariate Summaries")
hyp_test                     = figure_prop_emphasis(ce_hyp_test, question_text = "Hyp. Test")  
ci                           = figure_prop_emphasis(ce_CI, question_text = "Conf. Int.")
int_univariate_viz           = figure_prop_emphasis(ce_viz_1interp, question_text = "Interpret Univariate Viz")  
int_bivariate_viz            = figure_prop_emphasis(ce_viz_2interp, question_text = "Interpret Bivariate Viz")
int_multivariate_viz         = figure_prop_emphasis(ce_viz_3interp, question_text = "Interpret Multivariate Viz")
int_univariate_summary       = figure_prop_emphasis(ce_sum_1interp, question_text = "Interpret Univariate Summaries")  
int_bivariate_summary        = figure_prop_emphasis(ce_sum_2interp, question_text = "Interpret Bivariate Summaries")
int_multivariate_summary     = figure_prop_emphasis(ce_sum_3interp, question_text = "Interpret Multivariate Summaries")
comm_results                 = figure_prop_emphasis(ce_communicate_inf, question_text = "Communicate results")
p_value_decisions            = figure_prop_emphasis(ce_p_values, question_text = "p-Val. for Decision Making")
supplement_p_values          = figure_prop_emphasis(ce_supp_pvalue, question_text = "Supplement p-Values")
validity_of_results          = figure_prop_emphasis(ce_results_valid, question_text = "Validity of Results")
role_of_model                = figure_prop_emphasis(ce_assumptions, question_text = "Role of Model")
limits_inf                   = figure_prop_emphasis(ce_limitations, question_text = "Limitations of Inference") 


# Create Figure 3 (A)
fig_03_a = rbind(produce_univariate_viz, produce_bivariate_viz, produce_multivariate_viz, produce_univariate_summary, 
               produce_bivariate_summary, produce_multivariate_summary, hyp_test, ci) |>
  mutate(
    question = factor(question, levels = c("Conf. Int.", "Hyp. Test", "Produce Multivariate Summaries",
                                           "Produce Multivariate Viz", "Produce Bivariate Summaries", 
                                           "Produce Bivariate Viz", "Produce Univariate Summaries",
                                           "Produce Univariate Viz")),
    se = sqrt(p*(1 - p) / N),
    ll = p - qnorm(.975)*se,
    ul = p + qnorm(.975)*se,
  ) |>
  arrange(question) |>
  ggplot(aes(x = p, y = question)) +
  geom_linerange(aes(xmin = ll, xmax = ul), color = "#004488", size = 1.3) +
  geom_point(color = "#004488", size = 3) +
  guides(color = "none") +
  scale_x_continuous(
    name = "Percentage",
    breaks = seq(from = 0, to = 1, by = 0.2),
    minor_breaks = seq(from = 0.1, to = 0.9, by = 0.2),
    labels = scales::percent
  ) +
  coord_cartesian(xlim = c(0, 1)) +
  scale_y_discrete(
    name = "",
    labels = c("Conf. Int.", "Hyp. Test", "Produce\n Multivariate Summaries",
               "Produce\n Multivariate Viz", "Produce\n Bivariate Summaries", 
               "Produce\n Bivariate Viz", "Produce\n Univariate Summaries",
               "Produce\n Univariate Viz")
  ) +
  theme_bw() +
  theme(
    axis.text = element_text(size = rel(1.1)),
    axis.title = element_text(size = rel(1.1), face = "bold"),
    plot.title = element_textbox_simple(
      size = 14,
      lineheight = 1,
      padding = margin(5.5, 5.5, 5.5, 5.5),
      margin = margin(0, 0, 5.5, 0)
    )
  ) +
  ggtitle("<b style='color:#004488'>Analysis</b>")


# Create Figure 3 (B)
fig_03_b = rbind(int_univariate_viz, int_bivariate_viz, int_multivariate_viz, int_univariate_summary, int_bivariate_summary, 
                 int_multivariate_summary, p_value_decisions, supplement_p_values, validity_of_results, role_of_model,
                 limits_inf, comm_results) |>
  mutate(
    question = factor(question, levels = c("Limitations of Inference", "Role of Model", "Validity of Results",
                                           "Supplement p-Values",
                                           "p-Val. for Decision Making", "Communicate results", 
                                           "Interpret Multivariate Summaries", "Interpret Multivariate Viz",
                                           "Interpret Bivariate Summaries", "Interpret Bivariate Viz",
                                           "Interpret Univariate Summaries", "Interpret Univariate Viz")),
    se = sqrt(p*(1 - p) / N),
    ll = p - qnorm(.975)*se,
    ul = p + qnorm(.975)*se,
  ) |>
  arrange(question) |>
  ggplot(aes(x = p, y = question)) +
    geom_linerange(aes(xmin = ll, xmax = ul), color = "#BB5566", size = 1.3) +
    geom_point(color = "#BB5566", size = 3) +
  guides(color = "none") +
  scale_x_continuous(
    name = "Percentage",
    breaks = seq(from = 0, to = 1, by = 0.2),
    minor_breaks = seq(from = 0.1, to = 0.9, by = 0.2),
    labels = scales::percent
  ) +
  coord_cartesian(xlim = c(0, 1)) +
  scale_y_discrete(
    name = "",
    labels = c("Limitations\n of Inference", "Role of\n Model", "Validity\n of Results",
               "Supplement p-Values",
               "p-Val. for\n Decision Making", "Communicate results", 
               "Interpret\n Multivariate Summaries", "Interpret\n Multivariate Viz",
               "Interpret\n Bivariate Summaries", "Interpret\n Bivariate Viz",
               "Interpret\n Univariate Summaries", "Interpret\n Univariate Viz")
  ) +
  theme_bw() +
  theme(
    axis.text = element_text(size = rel(1.1)),
    axis.title = element_text(size = rel(1.1), face = "bold"),
    plot.title = element_textbox_simple(
      size = 14,
      lineheight = 1,
      padding = margin(5.5, 5.5, 5.5, 5.5),
      margin = margin(0, 0, 5.5, 0)
    )
  ) +
  ggtitle("<b style='color:#BB5566'>Conclusions</b>")




# Layout figure
fig_03_a | fig_03_b


